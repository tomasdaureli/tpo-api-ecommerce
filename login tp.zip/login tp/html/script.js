document.getElementById("signup-link").addEventListener("click", function(event) {
    event.preventDefault();
    alert("Aquí puedes implementar la lógica para mostrar el formulario de registro.");
    function validarContraseñas() {
        var password = document.getElementById("password").value;
        var confirmPassword = document.getElementById("confirm-password").value;
    
        if (password !== confirmPassword) {
            alert("Las contraseñas no coinciden. Por favor, inténtalo de nuevo.");
            return false; // Evita que se envíe el formulario si las contraseñas no coinciden
        }
    
        return true; // Envía el formulario si las contraseñas coinciden
    }
    
});